# Compteur de coffres Fortnite

Un petit compteur qui s'affiche par-dessus Fortnite pour suivre ton farm de coffres pendant la chasse au **jeton de la boutique pirate**.

- **Total global** sauvegardé (il reste même si tu fermes le script ou éteins le PC)
- Coffres **de la partie** et **du jour**, plus le **temps** de la partie
- Statut **EN PARTIE / EN ATTENTE** pour savoir si tes coffres sont bien comptés
- Ton pseudo **@user_oe6** affiché en petit sous le statut
- Une page d'**analyse** qui te dit à quel moment relancer ta partie pour ouvrir le plus de coffres par minute

> Projet de fan, non affilié à Epic Games. Le script n'envoie rien au jeu : il note juste l'heure dans un fichier quand tu appuies sur une touche.

## Installation

Il faut **Windows 10 ou 11** (AutoHotkey v2 ne marche pas sur les versions plus anciennes).

1. Mets tous les fichiers dans le **même dossier** (si tu les as en .zip, extrais-le d'abord) :
   `Lancer_compteur.bat`, `AutoHotkey_2_0_31_setup.exe`, `compteur_coffres.ahk`, `compteur_global.ini`, `coffres_log.csv`, `coffre.png` et `analyse.html`.
2. Double-clique sur `Lancer_compteur.bat`. Il installe AutoHotkey, puis lance le compteur tout seul. Accepte l'autorisation Windows si elle apparaît.
3. Une icône **H** verte apparaît près de l'horloge, et le compteur s'affiche en haut de l'écran.
4. Dans Fortnite, mets **Paramètres → Vidéo → Mode fenêtre : Plein écran fenêtré**. Sinon le compteur reste caché derrière le jeu.

Les fois suivantes, AutoHotkey est déjà installé : double-clique directement sur `compteur_coffres.ahk`.

Au tout premier lancement (si aucun total n'est enregistré), le script te demande combien de coffres tu as déjà ouverts : ton total global partira de ce nombre.

## Utilisation

| Touche | Action |
|---|---|
| **<** (à gauche de W) ou **Ctrl gauche** | Coffre ouvert ou cassé |
| **+** (pavé numérique ou clavier principal) | Début de partie (au moment où tu cliques sur « Jouer ») |
| **-** (pavé numérique ou clavier principal) | Fin de partie (mort ou tu quittes) |
| **F11** | Annuler la dernière saisie |
| **F12** | Cacher / afficher le compteur |

Les touches ne marchent que quand Fortnite est au premier plan, et le jeu les reçoit quand même. Si tu appuies sur un coffre sans avoir fait **+** avant, le coffre n'est pas compté et le compteur affiche « + d'abord ».

Les bips : aigu = coffre compté, moyen = début de partie, grave = fin de partie, très grave = coffre refusé (pas de partie en cours).

## Réglages

Ouvre `compteur_coffres.ahk` avec le Bloc-notes. Tout en haut, la section **RÉGLAGES** permet de changer :

| Réglage | Rôle |
|---|---|
| `TOUCHE_COFFRE` | Touche du coffre (par défaut `SC056`, la touche <). Exemple : `"XButton1"` pour un bouton latéral de souris |
| `TOUCHE_DEBUT` / `TOUCHE_DEBUT2` | Début de partie (`+` du pavé numérique et `+` du clavier principal) |
| `TOUCHE_FIN` / `TOUCHE_FIN2` | Fin de partie (`-` du pavé numérique et `-` du clavier principal) |
| `TOUCHE_ANNULER` / `TOUCHE_CACHER` | Annuler (F11) et cacher le compteur (F12) |
| `POSITION` | Place du compteur (par défaut centré en haut : `"xCenter y10"`). Exemple en haut à gauche : `"x20 y20"` |
| `ECHELLE` | Taille du compteur : 1 = petit, 1.5 = grand, 2 = très grand |
| `OPACITE` | 0 = invisible, 255 = opaque |
| `SONS` | `true` pour les bips, `false` pour les couper |
| `TOTAL_DEPART` | Total de départ, appliqué une seule fois |
| `JOUR_DEPART` | Coffres déjà ouverts aujourd'hui, appliqués une seule fois |

Après chaque changement, enregistre le fichier et relance le script.

Pour connaître le nom d'une touche, cherche « AutoHotkey v2 key list » : les touches normales s'écrivent avec leur lettre (`"a"`), les autres avec leur nom (`"F9"`, `"NumpadAdd"`) ou leur code (`"SC056"`).

Pour corriger ton total plus tard : ferme le script, ouvre `compteur_global.ini` et modifie la valeur après `total=`.

## Analyse : quand relancer ta partie ?

1. Joue une dizaine de parties en appuyant bien sur **+** au début et **-** à la fin.
2. Ouvre `analyse.html` dans ton navigateur.
3. Glisse-y le fichier `coffres_log.csv` qui s'est créé à côté du script.

La page te donne le moment idéal pour relancer, ton rendement actuel et ton rendement possible en coffres par minute, avec des graphiques.

## Fichiers créés

- `compteur_global.ini` : ton total global et tes totaux par jour. **Ne le supprime pas.**
- `coffres_log.csv` : l'historique de tes coffres, pour la page d'analyse.

## Sur une clé USB

Copie tout le dossier sur la clé et garde-la branchée pendant que tu joues : le total et l'historique s'enregistrent dans le dossier du script. Le lancement ne peut pas être automatique : il faut double-cliquer sur `Lancer_compteur.bat` (ou sur `compteur_coffres.ahk` si AutoHotkey est déjà installé sur le PC).
