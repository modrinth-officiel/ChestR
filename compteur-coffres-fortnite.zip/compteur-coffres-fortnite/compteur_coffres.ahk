; =====================================================================
;  Compteur de coffres Fortnite (AutoHotkey v2)
;  Un petit compteur par-dessus le jeu pour suivre ton farm de coffres
;  pendant la Chasse au jeton de la boutique pirate.
;
;  Touches par défaut (actives seulement quand Fortnite est au premier plan) :
;    A    -> coffre ouvert / cassé
;    F9   -> début de partie (clic sur "Jouer")
;    F10  -> fin de partie (mort / je quitte)
;    F11  -> annuler la dernière saisie
;    F12  -> cacher / afficher le compteur
;  Tu peux les changer dans la section RÉGLAGES juste en dessous.
;
;  Le compteur ne s'affiche par-dessus Fortnite qu'en mode
;  "Plein écran fenêtré" (Paramètres > Vidéo > Mode fenêtre).
;
;  Les touches ne sont pas bloquées : le jeu les reçoit quand même.
;  Le script n'envoie rien au jeu, il écrit juste l'heure dans un fichier.
;
;  Fichiers créés à côté du script :
;    compteur_global.ini -> ton total global et ton total du jour
;    coffres_log.csv     -> l'heure de chaque coffre (pour analyse.html)
; =====================================================================
#Requires AutoHotkey v2.0
#SingleInstance Force

; ======================= RÉGLAGES =======================
TOUCHE_COFFRE  := "a"     ; ex. "q" ou "XButton1" (bouton latéral de souris)
TOUCHE_DEBUT   := "F9"
TOUCHE_FIN     := "F10"
TOUCHE_ANNULER := "F11"
TOUCHE_CACHER  := "F12"
POSITION       := "xCenter y10"   ; centré en haut de l'écran
OPACITE        := 225     ; 0 = invisible, 255 = opaque
SONS           := true    ; petit bip à chaque appui
; ========================================================

INI := A_ScriptDir "\compteur_global.ini"
FICHIER_LOG := A_ScriptDir "\coffres_log.csv"
if !FileExist(FICHIER_LOG)
    FileAppend("evenement;horodatage_ms`n", FICHIER_LOG, "UTF-8")

; ---------- premier lancement : on demande les coffres déjà ouverts ----------
if (IniRead(INI, "compteur", "total", "") = "") {
    depart := 0
    Loop {
        rep := InputBox("Bienvenue !`n`nCombien de coffres as-tu déjà ouverts avant d'utiliser ce compteur ?`n(Mets 0 si tu ne sais pas, tu pourras corriger plus tard.)"
            , "Compteur de coffres - premier lancement", "w380 h190", "0")
        if (rep.Result != "OK")
            break
        v := Trim(StrReplace(StrReplace(rep.Value, " "), "."))
        if RegExMatch(v, "^\d+$") {
            depart := Integer(v)
            break
        }
        MsgBox("Entre seulement un nombre (par exemple 1500).", "Compteur de coffres", "Icon!")
    }
    IniWrite(depart, INI, "compteur", "total")
}
total := Integer(IniRead(INI, "compteur", "total", 0))
jour := FormatTime(, "yyyy-MM-dd")
coffresJour := Integer(IniRead(INI, "jours", jour, 0))
enPartie := false
coffresPartie := 0
debutTick := 0
historique := []
alerteJusqua := 0

; ---------- interface ----------
VIOLET := "24123F", DORE := "FFCF3F", LILAS := "C9C4FF", CASE_BG := "36205A"
W := 300

ov := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20")
ov.BackColor := VIOLET
ov.MarginX := 16, ov.MarginY := 12

ov.SetFont("s9 bold c" LILAS, "Segoe UI")
txtLabel := ov.AddText("w" (W-110) " Section", "COFFRES OUVERTS")
ov.SetFont("s9 bold", "Segoe UI")
txtEtat := ov.AddText("x+0 yp w110 Right", "")

ov.SetFont("s30 bold c" DORE, "Segoe UI Black")
txtTotal := ov.AddText("xs y+0 w160", "0")
if FileExist(A_ScriptDir "\coffre.png")
    ov.AddPicture("x+4 yp+8 h40 w-1", A_ScriptDir "\coffre.png")

; petit pseudo sous le statut (EN PARTIE / EN ATTENTE)
txtEtat.GetPos(&ex, &ey, &ew, &eh)
txtTotal.GetPos(&tx, &ty, &tw, &th)
ov.SetFont("s7 c" LILAS, "Segoe UI")
ov.AddText("x" ex " y" (ey + eh - 2) " w" ew " Right", "@user_oe6")

colW := (W - 2*8) // 3
ov.SetFont("s16 bold cWhite", "Segoe UI")
vPartie := ov.AddText("xs y" (ty + th + 6) " w" colW " Center Background" CASE_BG, "0")
vJour   := ov.AddText("x+8 yp w" colW " Center Background" CASE_BG, "0")
vTemps  := ov.AddText("x+8 yp w" colW " Center Background" CASE_BG, "0:00")
ov.SetFont("s7 bold c" LILAS, "Segoe UI")
ov.AddText("xs y+0 w" colW " Center Background" CASE_BG, "CETTE PARTIE")
ov.AddText("x+8 yp w" colW " Center Background" CASE_BG, "AUJOURD'HUI")
ov.AddText("x+8 yp w" colW " Center Background" CASE_BG, "TEMPS")

ov.Show(POSITION " NoActivate")
WinGetPos(, , &gw, &gh, ov)
try WinSetRegion("0-0 w" gw " h" gh " R24-24", ov)   ; coins arrondis
WinSetTransparent(OPACITE, ov)
visible := true

MAJ()
SetTimer(MAJ, 500)

; ---------- fonctions ----------
NowMs() => DateDiff(A_NowUTC, "19700101000000", "Seconds") * 1000 + A_MSec

Bip(freq, dur) {
    global SONS
    if SONS
        SoundBeep(freq, dur)
}

Ecrire(evt) {
    global FICHIER_LOG
    FileAppend(evt ";" NowMs() "`n", FICHIER_LOG, "UTF-8")
}

Milliers(n) => RegExReplace(n, "\G\d+?(?=(\d{3})+$)", "$0 ")

Persister() {
    global
    IniWrite(total, INI, "compteur", "total")
    IniWrite(coffresJour, INI, "jours", jour)
}

VerifierJour() {
    global
    j := FormatTime(, "yyyy-MM-dd")
    if (j != jour) {
        jour := j
        coffresJour := Integer(IniRead(INI, "jours", jour, 0))
    }
}

Sauver() {
    global
    historique.Push({en: enPartie, cp: coffresPartie, cj: coffresJour, dt: debutTick, tot: total})
}

MAJ(*) {
    global
    if (A_TickCount < alerteJusqua) {
        txtEtat.SetFont("cFFCC33"), txtEtat.Value := "⚠ F9 d'abord"
    } else if enPartie {
        txtEtat.SetFont("c3DFF8A"), txtEtat.Value := "● EN PARTIE"
    } else {
        txtEtat.SetFont("cFF5E6C"), txtEtat.Value := "○ EN ATTENTE"
    }
    txtTotal.Value := Milliers(total)
    vPartie.Value := coffresPartie
    vJour.Value := Milliers(coffresJour)
    if enPartie {
        s := (A_TickCount - debutTick) // 1000
        vTemps.Value := Format("{}:{:02}", s // 60, Mod(s, 60))
    } else {
        vTemps.Value := "0:00"
    }
}

Coffre(*) {
    global
    if !enPartie {
        alerteJusqua := A_TickCount + 2500
        Bip(200, 120)
        MAJ()
        return
    }
    VerifierJour()
    Sauver()
    Ecrire("coffre")
    coffresPartie += 1, coffresJour += 1, total += 1
    Persister()
    Bip(1200, 40)
    MAJ()
}

Debut(*) {
    global
    Sauver()
    Ecrire("debut")
    enPartie := true, coffresPartie := 0, debutTick := A_TickCount
    Bip(700, 60)
    MAJ()
}

Fin(*) {
    global
    if !enPartie
        return
    Sauver()
    Ecrire("fin")
    enPartie := false
    Bip(400, 60)
    MAJ()
}

Annuler(*) {
    global
    if historique.Length = 0
        return
    s := historique.Pop()
    enPartie := s.en, coffresPartie := s.cp, coffresJour := s.cj, debutTick := s.dt, total := s.tot
    Persister()
    Ecrire("annuler")
    Bip(250, 80)
    MAJ()
}

Basculer(*) {
    global
    visible := !visible
    visible ? ov.Show("NoActivate") : ov.Hide()
}

; ---------- touches ----------
HotIfWinActive("ahk_exe FortniteClient-Win64-Shipping.exe")
Hotkey("~" TOUCHE_COFFRE,  Coffre)
Hotkey("~" TOUCHE_DEBUT,   Debut)
Hotkey("~" TOUCHE_FIN,     Fin)
Hotkey("~" TOUCHE_ANNULER, Annuler)
Hotkey("~" TOUCHE_CACHER,  Basculer)
HotIfWinActive()
